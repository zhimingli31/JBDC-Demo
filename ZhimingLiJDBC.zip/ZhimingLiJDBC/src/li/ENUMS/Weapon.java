package li.ENUMS;

public enum Weapon {

	Blaster,
	Blaster_Rifle;
}
