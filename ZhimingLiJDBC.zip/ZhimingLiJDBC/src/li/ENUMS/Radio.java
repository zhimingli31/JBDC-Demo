package li.ENUMS;

public enum Radio {

	RTS_1,
	RTS_L2;
}
