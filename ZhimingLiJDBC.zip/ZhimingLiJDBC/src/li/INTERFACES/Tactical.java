package li.INTERFACES;

import li.MAIN.Location;

public interface Tactical {

	public abstract void moveTo(Location L);
}
